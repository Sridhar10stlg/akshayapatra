import React, { useState, useEffect } from 'react';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import '../Payment.css';
import { useNavigate } from 'react-router-dom';

const PaymentForm = ({ totalAmount, selectedItemsDetails }) => {
  const stripe = useStripe();
  const elements = useElements();
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentResult, setPaymentResult] = useState(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('card');
  const [upiId, setUpiId] = useState('');

  // const getCurrentDateTime = () => {
  //   const now = new Date();
  //   return now.toISOString(); // ISO format: YYYY-MM-DDTHH:mm:ss.sssZ
  // };
  // const getCurrentLocalDateTime = () => {
  //   const now = new Date();
  //   return now.toLocaleString('sv-SE', { timeZoneName: 'short' }).replace(' ', 'T');
  // };

  const getCurrentDateTime = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}.${milliseconds}`;
  };
  

  const transformData = (items) => {
    const orderDate = getCurrentDateTime();
    return {
      customerId: 'testuser1',
      orderDate: orderDate,
      itemsOrdered: items.map(item => ({
        itemId: item.itemId,
        itemName: item.itemName,
        quantity: item.quantity,
        pricePerQuantity: item.price.toString(),
        discount: item.discount, // Assuming no discount is provided in the current format
        categoryId: item.categoryId,
      }))
    };
  };

  const handleSubmit = async () => {

    const transformedData = transformData(selectedItemsDetails);

    try {
      const response = await fetch('https://0jdz7xjgnd.execute-api.us-east-2.amazonaws.com/DEV/API', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ body: transformedData })
      });

      console.log("successfully posted");

      if (response.ok) {
        const responseData = await response.json();
        console.log('Order successfully posted:', responseData);
      } else {
        console.error('Failed to post order:', response.statusText);
      }
    } catch (error) {
      console.error('Error posting order:', error);
    }
  };

  useEffect(() => {
    if (paymentResult === 'success') {
      handleSubmit();
      const timer = setTimeout(() => {
        navigate('/orderConfirmation');
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [paymentResult, navigate]);

  const handleCardPayment = async (event) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);

    try {
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: elements.getElement(CardElement),
        billing_details: {
          name: 'Test User',
        },
      });

      if (error) {
        setError('Payment failed: ' + error.message);
        setPaymentResult('fail');
        if (error.code === 'card_declined' && error.decline_code === 'generic_decline') {
          setError('Payment failed: Invalid card information.');
          setPaymentResult('fail');
        }
      } else {
        console.log('Payment Method:', paymentMethod);
        setPaymentResult('success');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Payment failed: ' + error.message);
      setPaymentResult('fail');
    } finally {
      setLoading(false);
    }
  };

  const handleUPIPayment = () => {
    if (upiId.endsWith('@okbank')) {
      setLoading(true);
      setError(null);
      setTimeout(() => {
        setPaymentResult('success');
        setLoading(false);
      }, 2000);
    } else {
      setPaymentResult('fail');
      setError('Payment failed: Enter a Valid UPI Id.');
    }
  };
  

  // const handleUPIPayment = () => {
  //   if (upiId.endsWith('@okbank')) {
  //     setPaymentResult('success');
  //     setError(null);
  //   } else {
  //     setPaymentResult('fail');
  //     setError('Payment failed: Enter a Valid UPI Id.');
  //   }
  // };

  const handlePaymentMethodChange = (event) => {
    setSelectedPaymentMethod(event.target.value);
  };

  const handleUPIIdChange = (event) => {
    setUpiId(event.target.value);
  };

  return (
    <div className="payment-form-container">
      <div className="payment-form">
        {paymentResult === 'success' && (
          <div className="payment-success">
            <div className="success-animation">
              <svg
                className="checkmark"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 52 52"
              >
                <circle className="checkmark__circle" cx="26" cy="26" r="25" fill="none" />
                <path
                  className="checkmark__check"
                  fill="none"
                  d="M14.1 27.2l7.1 7.2 16.7-16.8"
                />
              </svg>
            </div>
            Payment successful!
          </div>
        )}
        {paymentResult === 'fail' && (
          <div className="payment-error">{error}</div>
        )}
        {paymentResult !== 'success' && (
          <div>
            <div className="total-amount-display">
              To Pay: ₹{totalAmount}
            </div>
            <select
              className="payment-method-select"
              value={selectedPaymentMethod}
              onChange={handlePaymentMethodChange}
            >
              <option value="card">Card</option>
              <option value="upi">UPI</option>
            </select>
            {selectedPaymentMethod === 'card' ? (
              <form onSubmit={handleCardPayment}>
                <div className="card-element-container">
                  <CardElement className="card-element" />
                </div>
                <button
                  type="submit"
                  className="payment-button"
                  disabled={!stripe || loading}
                >
                  {loading ? 'Processing...' : 'Pay with Card'}
                </button>
                {error && <div className="payment-error">{error}</div>}
              </form>
            ) : (
              <div>
                <input
                  type="text"
                  placeholder="Enter UPI ID"
                  value={upiId}
                  onChange={handleUPIIdChange}
                  className="upi-input"
                />
                <button
                  onClick={handleUPIPayment}
                  className="payment-button"
                  disabled={loading || !upiId}
                >
                  {loading ? 'Processing...' : 'Pay with UPI'}
                </button>
                {error && <div className="payment-error">{error}</div>}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentForm;




// import React, { useState, useEffect } from 'react';
// import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
// import '../Payment.css';
// import { useNavigate } from 'react-router-dom';

// const PaymentForm = () => {
  
//   const stripe = useStripe();
//   const elements = useElements();
//   const navigate = useNavigate();
//   const [error, setError] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [paymentResult, setPaymentResult] = useState(null);
//   const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('card'); // Default to card payment
//   const [upiId, setUpiId] = useState(''); // Store the entered UPI ID for payment

//   useEffect(() => {
//     if (paymentResult === 'success') {
//       const timer = setTimeout(() => {
//         navigate('/orderConfirmation');  // Redirect to the desired page after 2-3 seconds
//       }, 1000);
//       return () => clearTimeout(timer);  // Cleanup the timer
//     }
//   }, [paymentResult, navigate]);

//   const handleCardPayment = async (event) => {
//     event.preventDefault();

//     if (!stripe || !elements) {
//       return;
//     }

//     setLoading(true);

//     try {
//       const { error, paymentMethod } = await stripe.createPaymentMethod({
//         type: 'card',
//         card: elements.getElement(CardElement),
//         billing_details: {
//           name: 'Test User',
//         },
//       });

//       if (error) {
//         setError('Payment failed: ' + error.message);
//         setPaymentResult('fail');
//         if (error.code === 'card_declined' && error.decline_code === 'generic_decline') {
//           setError('Payment failed: Invalid card information.');
//           setPaymentResult('fail');
//         }
//       } else {
//         console.log('Payment Method:', paymentMethod);
//         setPaymentResult('success');
//       }
//     } catch (error) {
//       console.error('Error:', error);
//       setError('Payment failed: ' + error.message);
//       setPaymentResult('fail');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleUPIPayment = () => {
//     // Simulating UPI payment success or failure
//     if (upiId.endsWith('@okbank')) {
//       setPaymentResult('success');
//       setError(null);
//     } else {
//       setPaymentResult('fail');
//       setError('Payment failed: Enter a Valid UPI Id.');
//     }
//   };

//   const handlePaymentMethodChange = (event) => {
//     setSelectedPaymentMethod(event.target.value);
//   };

//   const handleUPIIdChange = (event) => {
//     setUpiId(event.target.value);
//   };

//   return (
//     <div
//       style={{
//         display: 'flex',
//         justifyContent: 'center',
//         alignItems: 'center',
//         height: '90vh',
//       }}
//     >
//       <div style={{ width: '300px', textAlign: 'center' }}>
//         {/* {paymentResult === 'success' && (
//           <div style={{ marginBottom: '10px', color: 'green' }}>Payment successful!</div>
//         )} */}
//         {paymentResult === 'success' && (
//           <div style={{ marginBottom: '10px', color: 'green' }}>
//             <div className="success-animation">
//               <svg
//                 className="checkmark"
//                 xmlns="http://www.w3.org/2000/svg"
//                 viewBox="0 0 52 52"
//               >
//                 <circle className="checkmark__circle" cx="26" cy="26" r="25" fill="none" />
//                 <path
//                   className="checkmark__check"
//                   fill="none"
//                   d="M14.1 27.2l7.1 7.2 16.7-16.8"
//                 />
//               </svg>
//             </div>
//             Payment successful!
//           </div>
//         )}
//         {paymentResult === 'fail' && (
//           <div style={{ marginBottom: '10px', color: 'red' }}>{error}</div>
//         )}
//         {paymentResult !== 'success' && (
//           <div>
//             <select value={selectedPaymentMethod} onChange={handlePaymentMethodChange}>
//               <option value="card">Card</option>
//               <option value="upi">UPI</option>
//             </select>
//             {selectedPaymentMethod === 'card' ? (
//               <form onSubmit={handleCardPayment}>
//                 <CardElement />
//                 <button
//                   type="submit"
//                   style={{ marginTop: '10px', padding: '10px', width: '100%', cursor: 'pointer' }}
//                   disabled={!stripe || loading}
//                 >
//                   {loading ? 'Processing...' : 'Pay with Card'}
//                 </button>
//                 {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
//               </form>
//             ) : (
//               <div>
//                 <input
//                   type="text"
//                   placeholder="Enter UPI ID"
//                   value={upiId}
//                   onChange={handleUPIIdChange}
//                   style={{ marginTop: '10px', padding: '10px', width: '100%' }}
//                 />
//                 <button
//                   onClick={handleUPIPayment}
//                   style={{ marginTop: '10px', padding: '10px', width: '100%', cursor: 'pointer' }}
//                   disabled={loading || !upiId}
//                 >
//                   {loading ? 'Processing...' : 'Pay with UPI'}
//                 </button>
//                 {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
//               </div>
//             )}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default PaymentForm;